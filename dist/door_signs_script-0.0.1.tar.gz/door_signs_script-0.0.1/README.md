LBNL notebook for accelerated door sign creation
